# image_processing

Description
the package image_processing is send to:
    Prpcessing:
        - Histogram matching
        - Structural similar
        _ Resize image
    Utils:
        - Read image
        - Save image
        - Plot image
        - Plot result
        - Plot histogram

## Instalation

Use the package [pip](https://pip.in/en/stable/) to install package_name

```bash
pip install package_name
```

## Usage

```python
from package_name.model_name import file1_name
file1_name.my_function()
```

## Author
Lucas Florentino

## License
[MIT](https://choosealicense.com/licenses/mit/)